package com.neoris.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neoris.controllers.SecretariaController;
import com.neoris.model.service.imp.SecretariaImp;


public class SecretariaServlet extends HttpServlet {

	private static final long serialVersionUID = -4205078357168029062L;

	public SecretariaServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		SecretariaController secretariaC = new SecretariaController(new SecretariaImp());
		
		
		String dir = request.getParameter("dir");
		
		String ruta = secretariaC.devolverVista(dir);
		
		switch (dir) {
		case "registrar":
			List<String> listaNombres = Arrays.asList(request.getParameterValues("nombre[]"));
			List<String> listaApellidos = Arrays.asList(request.getParameterValues("apellido[]"));
			List<String> listaPosiciones = Arrays.asList(request.getParameterValues("posicion[]"));
			List<String> listaEdades = Arrays.asList(request.getParameterValues("edad[]"));
			List<String> listaAlturas = Arrays.asList(request.getParameterValues("altura[]"));
			List<String> listaPesos = Arrays.asList(request.getParameterValues("peso[]"));
			String mensaje = secretariaC.registrarJugadores(listaNombres, listaApellidos, listaPosiciones, listaEdades, listaAlturas, listaPesos);
			
			request.setAttribute("mensaje", mensaje);
			request.setAttribute("listaJugadores", secretariaC.mostrarListaRegistro());
			break;
		case "lista_jugadores":
			request.setAttribute("listaJugadores", secretariaC.mostrarListaJugadores());
			break;
		case "panel_registro":
			request.setAttribute("listaJugadores", secretariaC.mostrarListaRegistro());
			break;
		case "panel_de_control":
			request.setAttribute("volver", "dashboard_Secretaria");
			break;
		default:
			break;
		}
		
	
		RequestDispatcher rs = request.getRequestDispatcher(ruta);
		
		rs.forward(request, response);
		
	}

}
