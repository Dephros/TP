package com.neoris.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neoris.controllers.DTController;
import com.neoris.model.service.imp.DTImp;


@WebServlet("/DTServlet")
public class DTServlet extends HttpServlet {

	private static final long serialVersionUID = -1250020020504963481L;

    public DTServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		DTController dtC = new DTController(new DTImp());
		
		String dir = request.getParameter("dir");
		
		String ruta = dtC.devolverVista(dir);
		
		switch (dir) {
			case "calificar":
				List<String> listaCalificacion = Arrays.asList(request.getParameterValues("calificacion[]"));
				List<String> listaID = Arrays.asList(request.getParameterValues("idJugador[]"));
				dtC.calificarJugadores(listaID, listaCalificacion);
				request.setAttribute("listaJugadores", dtC.mostrarListaCompleta());
				break;
			case "lista_jugadores":
				request.setAttribute("listaJugadores", dtC.mostrarListaCalificada());
				break;
			case "panel_calificaciones":
				request.setAttribute("listaJugadores", dtC.mostrarListaCompleta());
				break;
			case "panel_de_control":
				request.setAttribute("volver", "dashboard_DT");
				break;
			default:
				break;
		}

		
		RequestDispatcher rs = request.getRequestDispatcher(ruta);
		
		rs.forward(request, response);
		
	}

}
