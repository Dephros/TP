package com.neoris.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neoris.controllers.LoginController;
import com.neoris.model.Usuario;
import com.neoris.model.service.imp.LoginImp;


public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = -2653232163844611841L;

	
	public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//request.getSession().invalidate();
		
		LoginController loginC = new LoginController(new LoginImp());
		
		String nombreUsuario = request.getParameter("nombreUsuario");
		String password = request.getParameter("password");
		
		Usuario usuario = loginC.validarLogin(nombreUsuario, password);
		
		String ruta = loginC.determinarVista(usuario);
		
		if(ruta == "index_Error.jsp") {
			
			String mensajeError = "La contrase�a es incorrecta o el usuario '" + nombreUsuario + "' no existe";
			request.setAttribute("mensajeError", mensajeError);
			
		}
		
		request.getSession().setAttribute("usuario", usuario);
		
		request.setAttribute("listaJugadores", loginC.mostrarJugadores());
		
		RequestDispatcher rs = request.getRequestDispatcher(ruta);
		
		rs.forward(request, response);
		
		
	}

}
