package com.neoris.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.neoris.controllers.PanelDeControlController;
import com.neoris.model.Usuario;
import com.neoris.model.service.imp.PanelDeControlImp;


@WebServlet("/PanelControlServlet")
public class PanelControlServlet extends HttpServlet {

	private static final long serialVersionUID = -7144702191434155061L;

    public PanelControlServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PanelDeControlController panelDeControlC = new PanelDeControlController(new PanelDeControlImp());
		
		String passwordActual = request.getParameter("passwordActual");
		String passwordNuevo = request.getParameter("passwordNuevo");
		String volver = request.getParameter("volver");
		
		Usuario usuario = (Usuario) request.getSession().getAttribute("usuario");
		
		
		request.setAttribute("volver", volver);
		request.setAttribute("mensajePassword", panelDeControlC.mensajeCambioPassword(usuario, passwordActual));
		
		Usuario nuevoUsuario = panelDeControlC.cambiarPassword(usuario, passwordActual, passwordNuevo);
		request.getSession().setAttribute("usuario", nuevoUsuario);
		
		RequestDispatcher rs = request.getRequestDispatcher(panelDeControlC.determinarVista());
		
		
		
		rs.forward(request, response);
		
		
	}

}
