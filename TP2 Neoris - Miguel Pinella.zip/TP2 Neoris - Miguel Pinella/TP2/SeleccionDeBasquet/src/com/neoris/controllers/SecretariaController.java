package com.neoris.controllers;

import java.util.List;

import com.neoris.model.JugadorBasquet;
import com.neoris.model.service.ISecretaria;

public class SecretariaController {
	
	private ISecretaria secretaria;
	
	public SecretariaController(ISecretaria secretaria) {
		this.secretaria = secretaria;
	}
	
	public String registrarJugadores(List<String> listaNombres, List<String> listaApellidos, List<String> listaPosiciones,
			List<String> listaEdades, List<String> listaAlturas, List<String> listaPesos) {
		
		return this.secretaria.registrarJugadores(listaNombres, listaApellidos, listaPosiciones, listaEdades, listaAlturas, listaPesos);
		
	}
	
	
	public List<JugadorBasquet> mostrarListaJugadores(){
		return this.secretaria.mostrarListaJugadores();
	}
	
	public List<JugadorBasquet> mostrarListaRegistro(){
		return this.secretaria.mostrarListaRegistro();
	}
	
	public String devolverVista(String dir) {
		
		switch (dir) {
		case "registrar":
			return "registrar_jugadores.jsp";
		case "lista_jugadores":
			return "dashboard_Secretaria.jsp";
		case "panel_registro":
			return "registrar_jugadores.jsp";
		case "panel_de_control":
			return "panel_de_control.jsp";
		default:
			return "dashboard_Secretaria.jsp";
			
		}
		
	}

}
