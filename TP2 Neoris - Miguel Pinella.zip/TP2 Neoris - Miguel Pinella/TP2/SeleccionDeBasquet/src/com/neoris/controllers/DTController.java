package com.neoris.controllers;

import java.util.List;

import com.neoris.model.JugadorBasquet;
import com.neoris.model.service.imp.DTImp;

public class DTController {
	
	private DTImp dt;
	
	public DTController(DTImp dt) {
		this.dt = dt;
	}
	
	public void calificarJugadores(List<String> listaID, List<String> listaCalificacion) {
		this.dt.calificarJugadores(listaID, listaCalificacion);
	}
	
	public String devolverVista(String dir) {
		
		switch (dir) {
		case "calificar":
			return "calificacion_jugadores.jsp";
		case "lista_jugadores":
			return "dashboard_DT.jsp";
		case "panel_calificaciones":
			return "calificacion_jugadores.jsp";
		case "panel_de_control":
			return "panel_de_control.jsp";
		default:
			return "dashboard_DT.jsp";
			
		}
		
	}
	
	public List<JugadorBasquet> mostrarListaCalificada(){
		return this.dt.mostrarListaCalificada();
	}
	
	public List<JugadorBasquet> mostrarListaCompleta(){
		return this.dt.mostrarListaCompleta();
	}
	
	

}
