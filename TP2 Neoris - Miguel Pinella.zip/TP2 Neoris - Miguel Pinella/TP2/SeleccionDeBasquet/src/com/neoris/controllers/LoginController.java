package com.neoris.controllers;

import java.util.List;

import com.neoris.model.JugadorBasquet;
import com.neoris.model.Usuario;
import com.neoris.model.service.ILogin;

public class LoginController {
	
	private ILogin login;
	
	public LoginController(ILogin login) {
		this.login = login;
	}
	
	public Usuario validarLogin(String nombreUsuario, String password) {
		
		return this.login.validarUsuario(nombreUsuario, password);
		
	}
	
	public String determinarVista(Usuario usuario) {
		
		switch (usuario.getNivelAcceso()) {
		case 1:
			return "dashboard_Secretaria.jsp";
			
		case 2:
			return "dashboard_DT.jsp";

		default:
			return "index_Error.jsp";
			
		}
	}
	
	public List<JugadorBasquet> mostrarJugadores(){
		return this.login.mostrarJugadores();
	}
	
	
}
