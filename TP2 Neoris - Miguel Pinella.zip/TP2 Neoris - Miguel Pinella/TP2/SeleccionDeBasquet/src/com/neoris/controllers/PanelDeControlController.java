package com.neoris.controllers;

import com.neoris.model.Usuario;
import com.neoris.model.service.IPanelDeControl;

public class PanelDeControlController {
	
	private IPanelDeControl panelDeControl;
	
	public PanelDeControlController(IPanelDeControl panelDeControl) {
		this.panelDeControl = panelDeControl;
	}
	
	public Usuario cambiarPassword(Usuario usuario, String passwordActual, String passwordNuevo) {
		return this.panelDeControl.cambiarPassword(usuario, passwordActual, passwordNuevo);

	}
	
	public boolean validarPassword(Usuario usuario, String passwordActual) {
		return this.panelDeControl.validarPassword(usuario, passwordActual);
	}
	
	public String mensajeCambioPassword(Usuario usuario, String passwordActual) {
		if(this.panelDeControl.validarPassword(usuario, passwordActual)) {
			return "Cambio de contrase�a exitoso";
		}else {
			return "Error al cambiar contrase�a";
		}
	}
	
	public String determinarVista() {
		return "panel_de_control.jsp";
	}

}
