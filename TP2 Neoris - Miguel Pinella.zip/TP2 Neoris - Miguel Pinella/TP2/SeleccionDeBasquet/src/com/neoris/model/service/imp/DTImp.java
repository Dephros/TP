package com.neoris.model.service.imp;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.neoris.dao.connection.MySqlDb;
import com.neoris.model.JugadorBasquet;
import com.neoris.model.service.IDT;

public class DTImp implements IDT {
	
	private MySqlDb conn;
	
	public DTImp() {
		this.conn = new MySqlDb();
	}

	@Override
	public void calificarJugadores(List<String> listaID, List<String> listaCalificacion) {
		
		try {

			for (int i = 0 ; i < listaID.size(); i++) {
				
				String sql = "UPDATE jugadores SET calificacion=? WHERE id =" + Integer.parseInt(listaID.get(i));
				
				
				PreparedStatement ps = this.conn.getConnection().prepareStatement(sql);
				
				ps.setInt(1, Integer.parseInt(listaCalificacion.get(i)));
				
				ps.executeUpdate();
	
			}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public List<JugadorBasquet> mostrarListaCalificada(){
		
		String sql = "select * from jugadores ORDER BY posicion DESC, calificacion DESC";
		
		List<JugadorBasquet> lista = new ArrayList<JugadorBasquet>();

		int base = 0;
		int ayudaBase = 0;
		int ala = 0;
		int alaPivot = 0;
		int pivot = 0;

		try {
			
			Statement st = this.conn.getConnection().createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				
				switch (rs.getString("posicion")) {
				case "Base":
					if(base < 3) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}else if(rs.getInt("calificacion") == lista.get(lista.size()-1).getCalificacion()) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}
					base ++;
					break;
				case "Ayuda Base":
					if(ayudaBase < 3) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}else if(rs.getInt("calificacion") == lista.get(lista.size()-1).getCalificacion()) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}
					ayudaBase ++;
					break;
				case "Ala":
					if(ala < 3) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}else if(rs.getInt("calificacion") == lista.get(lista.size()-1).getCalificacion()) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}
					ala ++;
					break;
				case "Ala Pivot":
					if(alaPivot < 3) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}else if(rs.getInt("calificacion") == lista.get(lista.size()-1).getCalificacion()) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}
					alaPivot ++;
					break;
				case "Pivot":
					if(pivot < 3) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}else if(rs.getInt("calificacion") == lista.get(lista.size()-1).getCalificacion()) {
						lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
					}
					pivot ++;
					break;

				default:
					break;
				}
				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return lista;
		
	}

	@Override
	public List<JugadorBasquet> mostrarListaCompleta() {
		
		String sql = "select * from jugadores ORDER BY posicion DESC, calificacion DESC";
		
		List<JugadorBasquet> lista = new ArrayList<JugadorBasquet>();
		
		
		try {
			
			Statement st = this.conn.getConnection().createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				
				
				lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"),rs.getInt("calificacion")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return lista;
	}

}
