package com.neoris.model.service.imp;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.neoris.dao.connection.MySqlDb;
import com.neoris.model.Usuario;
import com.neoris.model.service.IPanelDeControl;

public class PanelDeControlImp implements IPanelDeControl {
	
	private MySqlDb conn;
	
	public PanelDeControlImp() {
		this.conn = new MySqlDb();
	}

	@Override
	public Usuario cambiarPassword(Usuario usuario, String passwordActual, String passwordNuevo) {
		
		String sql = "select * from usuarios where id=" + usuario.getId();
		
		try {
			
			Statement st = this.conn.getConnection().createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				
				if(usuario.getNombreUsuario().equals(rs.getString("nombreUsuario")) && passwordActual.equals(rs.getString("password")) ) {
					String cambiarContrase�a = "UPDATE usuarios SET password=? WHERE id =" + usuario.getId();
					
					PreparedStatement ps = this.conn.getConnection().prepareStatement(cambiarContrase�a);

					ps.setString(1, passwordNuevo);
					
					ps.executeUpdate();
										
					Usuario u = new Usuario(usuario.getId(), usuario.getNombreUsuario(), passwordNuevo, usuario.getNivelAcceso());
					
					return u;
				}
				
			}
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return usuario;
		
	}


	@Override
	public boolean validarPassword(Usuario usuario, String passwordActual) {
		
		String sql = "select * from usuarios where id=" + usuario.getId();
		
		try {
			
			Statement st = this.conn.getConnection().createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				
				if(usuario.getNombreUsuario().equals(rs.getString("nombreUsuario")) && passwordActual.equals(rs.getString("password")) ) {
					
					return true;
										
				}
				
			}
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

}
