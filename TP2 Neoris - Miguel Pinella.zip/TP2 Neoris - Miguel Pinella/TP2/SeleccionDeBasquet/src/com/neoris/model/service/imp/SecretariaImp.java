package com.neoris.model.service.imp;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.neoris.dao.connection.MySqlDb;
import com.neoris.model.JugadorBasquet;
import com.neoris.model.service.ISecretaria;

public class SecretariaImp implements ISecretaria {
	
	private MySqlDb conn;
	
	public SecretariaImp() {
		this.conn = new MySqlDb();
	}

	@Override
	public String registrarJugadores(List<String> listaNombres, List<String> listaApellidos, List<String> listaPosiciones,
			List<String> listaEdades, List<String> listaAlturas, List<String> listaPesos) {
		
		String insertarJugador = "insert into jugadores (id,nombre,apellido,posicion,edad,altura,peso) values (?,?,?,?,?,?,?)";
		
		String sql = "select * from jugadores ORDER BY posicion DESC";
		
		List<JugadorBasquet> listaAux = new ArrayList<JugadorBasquet>();
		
		JugadorBasquet j;
		
		int base = 0;
		int ayudaBase = 0;
		int ala = 0;
		int alaPivot = 0;
		int pivot = 0;
		
		String mensaje = "";
		
		try {
			
			Statement st = this.conn.getConnection().createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				
				j = new JugadorBasquet(rs.getInt("id"),rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso"));
				listaAux.add(j);
				
				switch (rs.getString("posicion")) {
				case "Base":
					if(base < 4) {
						base ++;
					}
					break;
				case "Ayuda Base":
					if(ayudaBase < 4) {
						ayudaBase ++;
					}
					break;
				case "Ala":
					if(ala < 4) {
						ala ++;
					}					
					break;
				case "Ala Pivot":
					if(alaPivot < 4) {
						alaPivot ++;
					}
					break;
				case "Pivot":
					if(pivot < 4) {
						pivot ++;
					}
					break;

				default:
					break;
				}
						
			}
			
			System.out.println(listaAux.toString());

			for (int i = 0 ; i < listaNombres.size(); i++) {
				
				boolean noExiste = true;
				
				for (int k = 0; k < listaAux.size(); k++) {
					if(listaAux.get(k).getNombre().toLowerCase().contentEquals(listaNombres.get(i).toLowerCase()) && listaAux.get(k).getApellido().toLowerCase().contentEquals(listaApellidos.get(i).toLowerCase())) {
						if(mensaje.contentEquals("")) {
							mensaje = "Los siguientes jugadores ya estan registrados, o no hay cupo para hacerlo: <br>" +
						listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
						}else {
							mensaje += "<br>" + listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
						}
						noExiste = false;
					}
				}
				if(noExiste) {
					switch (listaPosiciones.get(i)) {
					case "Base":
						if(base < 4) {
							PreparedStatement ps = this.conn.getConnection().prepareStatement(insertarJugador);
							
							ps.setInt(1, 0);
							ps.setString(2, listaNombres.get(i));
							ps.setString(3, listaApellidos.get(i));
							ps.setString(4, listaPosiciones.get(i));
							ps.setInt(5, Integer.parseInt(listaEdades.get(i)));
							ps.setDouble(6, Double.parseDouble(listaAlturas.get(i)));
							ps.setDouble(7, Double.parseDouble(listaPesos.get(i)));
							
							ps.executeUpdate();
							base ++;
						}else {
							if(mensaje.contentEquals("")) {
								mensaje = "Los siguientes jugadores ya estan registrados, o no hay cupo para hacerlo: <br>" +
										listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}else {
								mensaje += "<br>" + listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}
						}
						break;
					case "Ayuda Base":
						if(ayudaBase < 4) {
							PreparedStatement ps = this.conn.getConnection().prepareStatement(insertarJugador);
							
							ps.setInt(1, 0);
							ps.setString(2, listaNombres.get(i));
							ps.setString(3, listaApellidos.get(i));
							ps.setString(4, listaPosiciones.get(i));
							ps.setInt(5, Integer.parseInt(listaEdades.get(i)));
							ps.setDouble(6, Double.parseDouble(listaAlturas.get(i)));
							ps.setDouble(7, Double.parseDouble(listaPesos.get(i)));
							
							ps.executeUpdate();
							ayudaBase ++;
						}else {
							if(mensaje.contentEquals("")) {
								mensaje = "Los siguientes jugadores ya estan registrados, o no hay cupo para hacerlo: <br>" +
										listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}else {
								mensaje += "<br>" + listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}
						}
						break;
					case "Ala":
						if(ala < 4) {
							PreparedStatement ps = this.conn.getConnection().prepareStatement(insertarJugador);
							
							ps.setInt(1, 0);
							ps.setString(2, listaNombres.get(i));
							ps.setString(3, listaApellidos.get(i));
							ps.setString(4, listaPosiciones.get(i));
							ps.setInt(5, Integer.parseInt(listaEdades.get(i)));
							ps.setDouble(6, Double.parseDouble(listaAlturas.get(i)));
							ps.setDouble(7, Double.parseDouble(listaPesos.get(i)));
							
							ps.executeUpdate();
							ala ++;
						}else {
							if(mensaje.contentEquals("")) {
								mensaje = "Los siguientes jugadores ya estan registrados, o no hay cupo para hacerlo: <br>" +
										listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}else {
								mensaje += "<br>" + listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}
						}
						break;
					case "Ala Pivot":
						if(alaPivot < 4) {
							PreparedStatement ps = this.conn.getConnection().prepareStatement(insertarJugador);
							
							ps.setInt(1, 0);
							ps.setString(2, listaNombres.get(i));
							ps.setString(3, listaApellidos.get(i));
							ps.setString(4, listaPosiciones.get(i));
							ps.setInt(5, Integer.parseInt(listaEdades.get(i)));
							ps.setDouble(6, Double.parseDouble(listaAlturas.get(i)));
							ps.setDouble(7, Double.parseDouble(listaPesos.get(i)));
							
							ps.executeUpdate();
							alaPivot ++;
						}else {
							if(mensaje.contentEquals("")) {
								mensaje = "Los siguientes jugadores ya estan registrados, o no hay cupo para hacerlo: <br>" +
										listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}else {
								mensaje += "<br>" + listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}
						}
						break;
					case "Pivot":
						if(pivot < 4) {
							PreparedStatement ps = this.conn.getConnection().prepareStatement(insertarJugador);
							
							ps.setInt(1, 0);
							ps.setString(2, listaNombres.get(i));
							ps.setString(3, listaApellidos.get(i));
							ps.setString(4, listaPosiciones.get(i));
							ps.setInt(5, Integer.parseInt(listaEdades.get(i)));
							ps.setDouble(6, Double.parseDouble(listaAlturas.get(i)));
							ps.setDouble(7, Double.parseDouble(listaPesos.get(i)));
							
							ps.executeUpdate();
							pivot ++;
						}else {
							if(mensaje.contentEquals("")) {
								mensaje = "Los siguientes jugadores ya estan registrados, o no hay cupo para hacerlo: <br>" +
										listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}else {
								mensaje += "<br>" + listaNombres.get(i) + " " + listaApellidos.get(i) + " posicion: " + listaPosiciones.get(i);
							}
						}
						break;
						
					default:
						break;
					}
					
				}

			}
	
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if(mensaje.contentEquals("")) {
			mensaje = "Registro de jugadores completado";
		}
		
		return mensaje;
		
	}

	@Override
	public List<JugadorBasquet> mostrarListaJugadores() {
		
		String sql = "select nombre, apellido, posicion from jugadores";
		
		List<JugadorBasquet> lista = new ArrayList<JugadorBasquet>();
		
		
		try {
			
			Statement st = this.conn.getConnection().createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				lista.add(new JugadorBasquet(rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		System.out.println(lista);
		
		return lista;
	}

	@Override
	public List<JugadorBasquet> mostrarListaRegistro() {
		
		String sql = "select * from jugadores";
		
		List<JugadorBasquet> lista = new ArrayList<JugadorBasquet>();
		
		
		try {
			
			Statement st = this.conn.getConnection().createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next()) {
				lista.add(new JugadorBasquet(rs.getInt("id"), rs.getString("nombre"),rs.getString("apellido"),rs.getString("posicion"),rs.getInt("edad"),rs.getDouble("altura"),rs.getDouble("peso")));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return lista;
	}

}
