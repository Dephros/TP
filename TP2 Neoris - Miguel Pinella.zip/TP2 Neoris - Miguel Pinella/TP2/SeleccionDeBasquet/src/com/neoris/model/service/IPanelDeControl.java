package com.neoris.model.service;

import com.neoris.model.Usuario;

public interface IPanelDeControl {
	
	public Usuario cambiarPassword(Usuario usuario, String passwordActual, String passwordNuevo);
	
	public boolean validarPassword(Usuario usuario, String passwordActual);

}
