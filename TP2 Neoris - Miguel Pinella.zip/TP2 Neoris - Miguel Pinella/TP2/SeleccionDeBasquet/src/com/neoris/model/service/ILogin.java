package com.neoris.model.service;

import java.util.List;

import com.neoris.model.JugadorBasquet;
import com.neoris.model.Usuario;

public interface ILogin {
	
	public Usuario validarUsuario(String nombreUsuario, String password);
	
	public void registrarUsuario(Usuario usuario);
	
	public List<JugadorBasquet> mostrarJugadores();
	

}
