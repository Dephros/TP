package com.neoris.model.service;

import java.util.List;

import com.neoris.model.JugadorBasquet;


public interface ISecretaria {

	public String registrarJugadores(List<String> listaNombres, List<String> listaApellidos, List<String> listaPosiciones,
			List<String> listaEdades, List<String> listaAlturas, List<String>listaPesos);
	
	public List<JugadorBasquet> mostrarListaJugadores();
	
	public List<JugadorBasquet> mostrarListaRegistro();
	
}
