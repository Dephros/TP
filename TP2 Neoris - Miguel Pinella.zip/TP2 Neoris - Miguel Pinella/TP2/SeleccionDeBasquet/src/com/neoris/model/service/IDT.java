package com.neoris.model.service;

import java.util.List;

import com.neoris.model.JugadorBasquet;

public interface IDT {
	
	public void calificarJugadores(List<String> listaID, List<String> listaCalificacion);
	
	public List<JugadorBasquet> mostrarListaCompleta();
	
	public List<JugadorBasquet> mostrarListaCalificada();

}
