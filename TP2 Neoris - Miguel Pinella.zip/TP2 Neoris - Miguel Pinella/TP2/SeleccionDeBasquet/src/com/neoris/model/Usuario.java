package com.neoris.model;

public class Usuario {
	
	private int id;
	private String nombreUsuario;
	private String password;
	private int nivelAcceso;

	
	public Usuario() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Usuario(String nombreUsuario, String password) {
		super();
		this.nombreUsuario = nombreUsuario;
		this.password = password;
	}



	public Usuario(int id, String nombreUsuario, String password, int nivelAcceso) {
		super();
		this.id = id;
		this.nombreUsuario = nombreUsuario;
		this.password = password;
		this.nivelAcceso = nivelAcceso;
	}



	public Usuario(String nombreUsuario, String password, int nivelAcceso) {
		super();
		this.nombreUsuario = nombreUsuario;
		this.password = password;
		this.nivelAcceso = nivelAcceso;
	}
	
	
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getNivelAcceso() {
		return nivelAcceso;
	}
	public void setNivelAcceso(int nivelAcceso) {
		this.nivelAcceso = nivelAcceso;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	@Override
	public String toString() {
		return "Usuario [nombreUsuario=" + nombreUsuario + ", password=" + password + ", nivelAcceso=" + nivelAcceso
				+ "]";
	}

}
