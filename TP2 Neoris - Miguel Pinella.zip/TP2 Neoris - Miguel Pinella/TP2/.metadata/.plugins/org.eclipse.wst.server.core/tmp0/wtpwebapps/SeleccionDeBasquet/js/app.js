function nuevaEntrada(){
	var contenedorPrincipal = document.getElementById("form");
	contenedorPrincipal.insertAdjacentHTML('beforeend', "<div class='input-container'></div>");
	
	var contenedorSecundario = contenedorPrincipal.getElementsByClassName("input-container");
	contenedorSecundario[contenedorSecundario.length-1].insertAdjacentHTML('beforeend', "<input class='form-input' type='text' name='nombre[]' placeholder='Nombre de Usuario' required>");
	contenedorSecundario[contenedorSecundario.length-1].insertAdjacentHTML('beforeend', "<input class='form-input' type='text' name='apellido[]' placeholder='Apellido' required>");
	contenedorSecundario[contenedorSecundario.length-1].insertAdjacentHTML('beforeend', "<select name='posicion[]' class='form-input' required><option value='Base'>Base</option><option value='Ayuda Base'>Ayuda Base</option><option value='Ala'>Ala</option><option value='Ala Pivot'>Ala Pivot</option><option value='Pivot'>Pivot</option></select>");
	contenedorSecundario[contenedorSecundario.length-1].insertAdjacentHTML('beforeend', "<input class='form-input' type='number' name='edad[]' placeholder='Edad' required>");
	contenedorSecundario[contenedorSecundario.length-1].insertAdjacentHTML('beforeend', "<input class='form-input' type='number' name='altura[]' placeholder='Altura' required>");
	contenedorSecundario[contenedorSecundario.length-1].insertAdjacentHTML('beforeend', "<input class='form-input' type='number' name='peso[]' placeholder='Peso' required>");

}

function listaVacia(){
	var fieldset = document.getElementsByClassName("fieldset");
	
	for( var i = 0; i < fieldset.length; i++){
		if(fieldset[i].children.length <= 1){
			fieldset[i].insertAdjacentHTML('beforeend', "<span>No hay jugadores cargados para esta posicion.</span>");
		}
	}
	
}

function faltaCalificar(){
	var fieldset = document.getElementsByClassName("fieldset");
	
	for(var i = 0; i < fieldset.length; i ++){
		
		var jugadores = fieldset[i].getElementsByClassName("jugador");
		
		
		var sinCalificar = true;
		var j = jugadores.length -1;
		
		while(sinCalificar && (j > 0)){
			if(jugadores[j].lastElementChild.value == -1){
				if(jugadores[j-1].lastElementChild.value == -1){
					jugadores[j].style.background = "rgba(228, 228, 23, 0.62)";
					jugadores[j-1].style.background = "rgba(228, 228, 23, 1)";
				}else if(jugadores[j].style.background == "rgba(228, 228, 23, 0.62)"){
					jugadores[j].style.background = "rgba(228, 228, 23, 0.62)";
				}else if(jugadores[j].style.background == "rgba(228, 228, 23, 1)"){
					jugadores[j].style.background == "rgba(228, 228, 23, 1)";
				}else{
					jugadores[j].style.background = "rgba(228, 228, 23, 0.62)";
				}
				
				
			}else{
				sinCalificar = false;
			}
			
			j--;
			
		}
		
		
	}

}

function marcarEmpate(){
	var fieldset = document.getElementsByClassName("fieldset");
	
	for(var i = 0; i < fieldset.length; i ++){
		
		var jugadores = fieldset[i].getElementsByClassName("jugador");
		
		if(jugadores.length > 3){
			
			var hayEmpate = true;
			var j = jugadores.length -1;
			
			while(hayEmpate && (j > 0)){
				if(jugadores[j].lastElementChild.value == jugadores[j-1].lastElementChild.value){
					if(jugadores[j-1].style.background == "rgba(236, 73, 5, 1)"){
						jugadores[j].style.background = "rgba(236, 73, 5, 0.62)";
					}else if(jugadores[j-1].style.background == "rgba(236, 73, 5, 0.62)"){
						jugadores[j].style.background = "rgba(236, 73, 5, 1)";
					}else{
						jugadores[j].style.background = "rgba(236, 73, 5, 0.62)";
						jugadores[j-1].style.background = "rgba(236, 73, 5, 1)";
					}
				}else{
					hayEmpate = false;
				}
				
				j--;
				
			}
			
		}

	}

}

function cambiarVista(){
	var formularios = document.getElementById("navegar");
	formularios.submit();
}

function panelDeControl(){
	var formularios = document.getElementById("panel_de_control");
	formularios.submit();
}

function enviarFormularios(){
	var formularios = document.getElementById("form");
	var inputs = formularios.getElementsByClassName("form-input");
	
	var verificarCampos = true;
	
	for(var i = 0; i < inputs.length; i++){
		if(inputs[i].value == "" || inputs[i].value == null){
			verificarCampos = false;
			inputs[i].style.border="1px solid red";
		}
	}
	
	if(verificarCampos == true){
		formularios.submit();		
	}
}

function cambiarPassword(){
	var formulario = document.getElementById("cambiarPassword");
	var inputs = formulario.getElementsByClassName("form-input");
	
	var verificarCampos = true;
	
	for(var i = 0; i < inputs.length; i++){
		if(inputs[i].value == "" || inputs[i].value == null){
			verificarCampos = false;
			inputs[i].style.border="1px solid red";
		}
	}
	
	if(inputs[1].value != inputs[2].value){
		verificarCampos = false;
		inputs[2].style.border="1px solid red";
	}
	
	if(verificarCampos == true){
		formulario.submit();		
	}
}

function desplegarMenu(){
	document.getElementById("menuUsuario").style.display="block";
}

function cerrarMenu(){
	document.getElementById("menuUsuario").style.display="none";
}

function calificacionMaxima(){
	if(this.value > 100){
		this.value = 100;
	}
}